-- name: [AM] Example Pack
-- description: Official example addon for SM64Coop Achievements Mod.\nShows how to register custom achievements, custom textures, and triggers!

-- Helper function: loads a PNG from this mod's /textures/ folder by exact filename
local function tex(name)
    return get_texture_info(name)
end

hook_event(HOOK_ON_MODS_LOADED, function()
    -- 1. Check if the base Achievements Mod is active
    if not _G.AchievementsAPI then
        djui_chat_message_create("\\#ff5555\\[AM Example Pack]\\#ffffff Requires SM64Coop Achievements Mod!")
        return
    end

    local API = _G.AchievementsAPI

    -- ============================================================
    -- EXAMPLE 1: ACTION TRIGGER (Perform 5 Backflips)
    -- Looks for: textures/ex_backflip.png
    -- ============================================================
    API.register({
        id      = "ex_backflip_5",
        title   = "Acrobatic Plumber",
        desc    = "Perform 5 backflips",
        icon    = tex("ex_backflip"),
        trigger = API.TRIGGER.ACTION,
        value   = ACT_BACKFLIP,
        goal    = 5
    })

    -- ============================================================
    -- EXAMPLE 2: LEVEL ENTER TRIGGER (Visit Cool, Cool Mountain)
    -- Looks for: textures/ex_snow.png
    -- ============================================================
    API.register({
        id      = "ex_visit_ccm",
        title   = "Winter Vacation",
        desc    = "Enter Cool, Cool Mountain",
        icon    = tex("ex_snow"),
        trigger = API.TRIGGER.LEVEL_ENTER,
        value   = LEVEL_CCM
    })

    -- ============================================================
    -- EXAMPLE 3: COIN COUNT TRIGGER (Collect 25 Coins)
    -- Looks for: textures/ex_coins.png
    -- ============================================================
    API.register({
        id      = "ex_collect_25_coins",
        title   = "Pocket Change",
        desc    = "Hold 25 coins in any course",
        icon    = tex("ex_coins"),
        trigger = API.TRIGGER.COIN_COUNT,
        value   = 25
    })

    -- ============================================================
    -- EXAMPLE 4: INTERACT TRIGGER (Read 3 Wooden Signs)
    -- Looks for: textures/ex_sign.png
    -- ============================================================
    API.register({
        id      = "ex_read_3_signs",
        title   = "Careful Reader",
        desc    = "Interact with wooden signs 3 times",
        icon    = tex("ex_sign"),
        trigger = API.TRIGGER.INTERACT,
        value   = id_bhvSignOnWall,
        goal    = 3
    })

    -- ============================================================
    -- EXAMPLE 5: CUSTOM / MANUAL TRIGGER (Unlocked via custom code below)
    -- Looks for: textures/ex_taunt.png
    -- ============================================================
    API.register({
        id      = "ex_custom_ground_pound",
        title   = "Earthquake!",
        desc    = "Land a heavy Ground Pound",
        icon    = tex("ex_taunt"),
        trigger = API.TRIGGER.CUSTOM
    })
end)

-- ============================================================
-- CUSTOM LOGIC FOR EXAMPLE 5 (API.TRIGGER.CUSTOM)
-- You can unlock custom achievements anywhere in your own hooks!
-- ============================================================
hook_event(HOOK_MARIO_UPDATE, function(m)
    if m.playerIndex ~= 0 or not _G.AchievementsAPI then return end

    if m.action == ACT_GROUND_POUND_LAND then
        _G.AchievementsAPI.unlock("ex_custom_ground_pound")
    end
end)
